package main

import (
	"context"
	"crypto/ecdsa"
	"fmt"
	"log"
	"math/big"

	MyContract "smart-contract-connector/contracts"

	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient"
)

const bscTestNetworkUrl = "https://data-seed-prebsc-1-s1.binance.org:8545/"
const bscTestNetworkChainId = 97
const privateKey = ""        // put your private key here
const publicKey = ""         // put your public key here
const MyContractAddress = "" // put your contract address here

func main() {
	client, err := ethclient.Dial(bscTestNetworkUrl) // bsc test network

	if err != nil {
		log.Fatal(err)
		return
	}

	contract, err := MyContract.NewMyContract(common.HexToAddress(MyContractAddress), client)

	if err != nil {
		log.Fatal(err)
		return
	}

	// increase counter
	txOpts, err := GetDefautlTransactionOpts(client, privateKey, bscTestNetworkChainId)

	if err != nil {
		log.Fatal(err)
		return
	}

	contract.Increase(txOpts)

	// get counter
	callOpts := GetDefaultCallOpts(publicKey)
	counter, err := contract.GetYourCounter(callOpts)

	if err != nil {
		log.Fatal(err)
		return
	}

	fmt.Println(counter.Text(10))
}

// Get default CallOpts
func GetDefaultCallOpts(publicKey string) *bind.CallOpts {
	return &bind.CallOpts{Pending: false, From: common.HexToAddress(publicKey), BlockNumber: nil, Context: nil}
}

// Get default TransactionOpts
func GetDefautlTransactionOpts(client *ethclient.Client, privateKeyStr string, chainId uint64) (*bind.TransactOpts, error) {
	privateKey, err := crypto.HexToECDSA(privateKeyStr)
	if err != nil {
		return nil, err
	}

	publicKey := privateKey.Public()
	publicKeyECDSA, ok := publicKey.(*ecdsa.PublicKey)
	if !ok {
		return nil, err
	}

	fromAddress := crypto.PubkeyToAddress(*publicKeyECDSA)

	nonce, err := client.PendingNonceAt(context.Background(), fromAddress)
	if err != nil {
		return nil, err
	}

	gasPrice, err := client.SuggestGasPrice(context.Background())
	if err != nil {
		return nil, err
	}

	txOpts, err := bind.NewKeyedTransactorWithChainID(privateKey, big.NewInt(int64(chainId)))
	if err != nil {
		return nil, err
	}

	txOpts.Nonce = big.NewInt(int64(nonce))
	txOpts.Value = big.NewInt(0)
	txOpts.GasLimit = 3000000
	txOpts.GasPrice = gasPrice

	return txOpts, nil
}
